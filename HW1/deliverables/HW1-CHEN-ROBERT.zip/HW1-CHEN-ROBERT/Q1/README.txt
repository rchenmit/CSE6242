** code was tested on Mac OSX 10.9.4 ** 

** assuming you are in this directory (Q1), do the following: **

pip install urllib2
pip install time
pip install lxml
pip install StringIO
pip install json
pip install webbrowser
pip install  md5
pip install  numpy as np
pip install  pandas as pd
pip install  collections
pip install  urllib
pip install  urlparse

python getsimilartracks_cher_believe.py


